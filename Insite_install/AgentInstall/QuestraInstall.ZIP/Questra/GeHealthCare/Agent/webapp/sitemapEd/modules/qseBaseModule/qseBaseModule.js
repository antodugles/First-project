/*******************************************************************************
 *
 *  Copyright Questra Corp.
 *      All rights reserved
 *
 */

/*******************************************************************************
 *
 *  
 */
function QSEBaseModule( name, className, label, group, initXML ) {
    /**
     *  data used by the UI framework
     */
    this.className      = className;
    this.name       = name;
    this.label      = label;
    this.group      = group;
    this.groupDisp  = 0;
    this.display    = 0;
    this.bodyMarkup = null;
    this.buttons    = null;
}

/**********************************************************************
 *
 *  Functions that implement the required module interface
 */
QSEBaseModule.prototype.getClassName = function() {
    return this.className;
}

QSEBaseModule.prototype.getModuleName = function() {
    return this.name;
}

QSEBaseModule.prototype.getLabel = function() {
    return this.label;
}

QSEBaseModule.prototype.getGroupName = function() {
    return this.group;
}

QSEBaseModule.prototype.getGroupDisp = function() {
    return this.groupDisp;
}

QSEBaseModule.prototype.getButtons = function() {
    return this.buttons;
}

QSEBaseModule.prototype.getMarkup = function() {
    return this.markup;
}

QSEBaseModule.prototype.getData = function() {
    var data = new Array();
    return data;
}

QSEBaseModule.prototype.show = function() {
}

QSEBaseModule.prototype.hide = function() {
}

QSEBaseModule.prototype.init = function( instanceNode ) {
}

/**
 *  The saveHandler, resetHandler and testHandler functions are registered
 *  as an event handlers for the dialog buttons.  As a result, the functions
 *  will always be called in the scope of the dialog ( 'this' will be the 
 *  dialog object ).  Use the QSEParentModule property of the dialog to 
 *  get the module object.
 */
QSEBaseModule.prototype.saveHandler = function( event ) {
}

QSEBaseModule.prototype.resetHandler = function( event ) {
}
