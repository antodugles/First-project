/*******************************************************************************
 *
 *  Copyright Questra Corp.
 *      All rights reserved
 *
 */

/*******************************************************************************
 *
 */
function NVP( name, value, purpose ) {
    this.name = name;
    this.value = value;
    this.purpose = purpose;
}

/*******************************************************************************
 *
 *
 */
function CommitRequest() {
    this.doc = new XDocument();
    this.root = this.doc.createElement( 'commitRequest' );
    this.doc.appendChild( this.root );
}

CommitRequest.prototype.addTag = function( avp ) {
    var elem = this.doc.createElement( 'Tag' );
    elem.setAttribute( 'name', avp.name );
    elem.setAttribute( 'value', avp.value );
    this.root.appendChild( elem );
}

CommitRequest.prototype.toString = function() {
    return xmlText( this.doc );
}

/*******************************************************************************
 *
 *
 */
function DataPoint( name, label, value, type, min, max, values ) {
    this.name   = name;
    this.label  = label;
    this.value  = value;
    this.type   = type;
    this.min    = min;
    this.max    = max;
    this.values = new Array();
    for( var i = 0; i < values.length; ++i ) {
        this.values.push( values[ i ] );
    }
}

function getAttrValue( attr, ctx ) {
    var node = xpathEval( '@' + attr, ctx );
    if( null != node ) {
        return node.stringValue();
    }
    return "";
}

/*******************************************************************************
 *
 *	Returns the names of all the obj's
 *	variables and functions in a sorted array
 */
function getMembers( obj, print ) {
    try {
    	var members = new Array();
    	var values  = new Array();
    	var i = 0;
    
    	for( var member in obj ) {
    		members[i] = member;
    		values[i] = obj[member];
    		++i;
    	}
    
    	if( false == print ) {
    		return members.sort();
    	}
    	else {
    		for( var i = 0; i < members.length; ++i ) {
    			alert( members[i] + " = " +  values[i] );
    		}
    		return members.sort();
    	}
    }
    catch( e ) {
        alert( 'Caught exception: ' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
}

/*******************************************************************************
 *
 */
function getText( nl )
{
	var retVal = "";
	if( null != nl ) {
		var ns = nl.nodeSetValue()[0];
		if( null != ns ) {
			var fc = ns.firstChild;
			if( null != fc ) {
				var val = fc.nodeValue;
				if( null != val ) {
					retVal = val;
				}
			}
		}
	}
	
	return retVal;
}

/*******************************************************************************
 *
 */
function buildDocumentIE() {
	var versions = [
		"MSXML2.DOMDocument.5.0",
		"MSXML2.DOMDocument.4.0",
		"MSXML2.DOMDocument.3.0",
		"MSXML2.DOMDocument",
		"Microsoft.XmlDom"
	];

	for( var i = 0; i < versions.length; ++i ) {
		try {
			var doc = new ActiveXObject( versions[i] );
			return doc;
		}
		catch( error ) {
			//	ignore the error
		}
	}
	
	throw new Error( 'MSXML is not installed on this computer' );
}

/*******************************************************************************
 *
 */
function buildDocument( txt ) {
	var doc = null;

	if( window.ActiveXObject ) {
		//	Internet Explorer
		doc = buildDocumentIE();
  		doc.async = "false";
		doc.loadXML( txt );
	}
	else {
		//	Firefox / Mozilla / Opera / Everyone else
		var parser = new DOMParser();
		var doc = parser.parseFromString( txt, "text/xml" );
	}

	return doc;
}

/*******************************************************************************
 *
 */
function taConnection( n, l, a, i, s, x, c ) {
	if( null == n || "" == n ) {
		this.name	= l;
	}
	else {
		this.name	= n;
	}
	this.label		= l;
	this.active		= a;
	this.state		= s;
	this.init		= i;
	this.address	= x;
	this.numConn	= c;
}

/*******************************************************************************
 *
 */
function filewatcher( l, a, p ) {
	this.active	= a;
	this.label	= l;
	this.path	= p;
}
