function ltrim(argvalue, replacedChar) 
{
   while (1) 
   {
      if (argvalue.substring(0, 1) != replacedChar)
         break;
      argvalue = argvalue.substring(1, argvalue.length);
 }

  return argvalue;
}

function setCurrentTime( thisCtrl )
{
   if( thisCtrl.checked )
   {
      var curDate = new Date();
      //alert( curDate );
      var month = curDate.getMonth() + 1;
      document.forms[0].startDate.value = (month < 10 ? "0" : "") + month + "-" + curDate.getDate() + "-" + curDate.getFullYear();
      var hour = curDate.getHours();
      var minute = curDate.getMinutes();
      document.forms[0].startTime.value = (hour < 10 ? "0" : "" ) + hour  + ":" + (minute < 10 ? "0" : "") + minute;
      thisCtrl.form.startDate.disabled = true;
      thisCtrl.form.startTime.disabled = true;
   } else {
      thisCtrl.form.startDate.disabled = false;
      thisCtrl.form.startTime.disabled = false;
   }
}

function isValidDate(daDate) {
   if (daDate.match(/(\d{1,2})-(\d{1,2})-(\d{4})/)) 
   {
      var daMonth   = parseInt(ltrim(RegExp.$1,"0")) - 1
      var daDay = parseInt(ltrim(RegExp.$2, "0"))
      var daYear  = parseInt(RegExp.$3)
      
      var checkDate = new Date(daYear, daMonth, daDay)
      if ( (checkDate.getMonth()    == daMonth) &&
           (checkDate.getDate()     == daDay  ) &&
           (checkDate.getFullYear() == daYear )
         ) 
      {
            return true
      }
   }
   return false
}

function isValidTime(daTime)
{
   if (daTime == "" || daTime.match(/(\d{1,2}):(\d{1,2})/)) 
   {
      return true;
   }
   return false
}


function submitForm()
{
   if( !isValidDate( document.forms[0].startDate.value ) )
   {
      alert( "Please enter a valid date." );
      return;
   }
   if( !isValidTime( document.forms[0].startTime.value ) )
   {
      alert( "Please enter a valid time." );
      return;
   }
   document.forms[0].submit();
}


function changeFrequency( url )
{
   window.location.href = url;
}

function changeDTboxState( thisCtrl )
{
   if( thisCtrl.checked )
   {
      thisCtrl.form.startDate.disabled = true;
      thisCtrl.form.startTime.disabled = true;
   } else {
      thisCtrl.form.startDate.disabled = false;
      thisCtrl.form.startTime.disabled = false;
   }
}
