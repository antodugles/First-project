/*******************************************************************************
 *
 *  Copyright Questra Corp.
 *      All rights reserved
 *
 */

/*******************************************************************************
 *
 */
(function() {
    YAHOO.util.Event.onDOMReady(
        function() {
            try {
                var callback = {
                    success : function( resp ) {
                        
        
                        YAHOO.log( '\n\nProxy module\n' +
                                   resp.status + '\n' +
                                   resp.responseText
                                 );
                                 
                        var ctx = new ExprContext( xmlParse( resp.responseText ) );
                        var nodes = xpathEval( '/initializeResponse/instance', ctx );
                        
                        YAHOO.log( nodes.toString() );
                        
                        if( null != nodes ) {
                            var nodeSet = nodes.nodeSetValue();
                            YAHOO.log( 'Generating module ' +  nodeSet.length + ' instances' );
                            for( var i = 0; i < nodeSet.length; ++i ) {
                                var m = new QSEProxyModule();
                                m.init( nodeSet[ i ] );
                                qse.registerModuleInstance( m );
                                qse.registerStatusModule( m );
                            }
                        }
                        else {
                            alert( 'No moduleContainers found during initialization' );
                        }
                        delete ctx;
                        YAHOO.log( 'Registration done event firing' );
                        qse.registrationDoneEvent.fire( m.getClassName() );
                    },
                    failure : function( resp ) {
                        alert( 'QSEProxyModule: Initialization failed: ' +
                               'Status: ' + resp.status + '\n' +
                               'Status message: ' + resp.statusText );
                    },
                    timeout : qse.getTransactionTimeout()
                }
        
                var postBody = '';
                var url = "/QSEProxyModule/initialize";
                YAHOO.util.Connect.initHeader( 'ContentType', 'text/xml' );
                YAHOO.util.Connect.asyncRequest( 'POST', url,
                                                 callback, postBody );
            }
            catch( e ) {
                alert( 'Caught exception: ' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
            }
        }
    );
})();

/**
 *  The saveHandler_g, resetHandler_g and testHandler_g functions are in the
 *  global scope because they are registered as event handlers on the dialog
 *  buttons.  As a result, the functions will always be called in the scope of 
 *  the dialog ( 'this' will be the dialog object ).  The QSEParentModule
 *  property of the dialog will be the module object and can be used to get
 *  into the proper scope.
 */
saveHandler_g = function( event ) {
    this.QSEParentModule.saveHandler( this.getData() );
}

resetHandler_g = function( event ) {
    this.QSEParentModule.resetHandler( this.getData() );
}

testHandler_g = function( event ) {
    this.QSEParentModule.testHandler( this.getData() );
}

/*******************************************************************************
 *
 *  Proxy module 
 */
function QSEProxyModule() {
    /**
     *  data needed by the framework
     */
    this.className = "QSEProxyModule";
    this.name = "";
    this.label = "";
    this.group = "";
    this.buttons = [
        { text: "Test Connection", handler: testHandler_g },
        { text: "Ok",              handler: saveHandler_g, isdefault: true },
        { text: "Reset",           handler: resetHandler_g }
    ];

    /**
     *  constant strings
     */
    this.PROXY_NONE       = 'noProxy';
    this.PROXY_YES        = 'proxy';
    this.PROXY_NO_AUTH    = 'noAuth';
    this.PROXY_BASIC_AUTH = 'basicAuth';
    this.PROXY_NTLM_AUTH  = 'ntlmAuth';

    /**
     *  User editable data
     */
    this.type           = this.PROXY_NONE;
    this.hostname       = '';
    this.port           = '';
    this.domain         = '';
    this.username       = '';
    this.password       = '';
    this.confirm        = '';
    this.names          = new Array();

    this.testDate       = 'N/A';
    this.testResult     = 'N/A';
    this.testDetail     = 'N/A';

    /***************************************************************************
     *
     *  Overrides and additions
     */
    this.getStatus = function() {
        if( this.type == this.PROXY_NONE ) {
            return "Ok";
        }
        else {
            return this.testResult;
        }
    }
    
    this.getStatusLabel = function() {
        return this.label;
    }
    
    this.getStatusDescription = function() {
        return this.getAddress();
    }

    this.getStatusDate = function() {
        return this.testDate;
    }
    
    this.getTestResult = function() {
        if( this.type == this.PROXY_NONE ) {
            return "Ok";
        }
        else {
            return this.testResult;
        }
    }
    
    this.getStatusDetail = function() {
        return this.testDetail;
    }

    this.getTestData = function() {
        var data = new Array();
        if( this.PROXY_NONE == this.type ) {
            data.push( new NVP( this.names.type, this.type, 'proxyAuthScheme' ) );
            data.push( new NVP( this.names.address, "", 'proxyAddress' ) );
            data.push( new NVP( this.names.username, "", 'proxyUsername' ) );
            data.push( new NVP( this.names.password, "", 'proxyPassword' ) );
        }
        else if( this.PROXY_NO_AUTH == this.type ) {
            data.push( new NVP( this.names.type, this.type, 'proxyAuthScheme' ) );
            data.push( new NVP( this.names.address, this.getAddress(), 'proxyAddress' ) );
            data.push( new NVP( this.names.username, "", 'proxyUsername' ) );
            data.push( new NVP( this.names.password, "", 'proxyPassword' ) );
        }
        else if( this.PROXY_BASIC_AUTH == this.type ) {
            data.push( new NVP( this.names.type, this.type, 'proxyAuthScheme' ) );
            data.push( new NVP( this.names.address, this.getAddress(), 'proxyAddress' ) );
            data.push( new NVP( this.names.username, this.getUsername(), 'proxyUsername' ) );
            data.push( new NVP( this.names.password, this.password, 'proxyPassword' ) );
        }
        else if( this.PROXY_NTLM_AUTH == this.type ) {
            data.push( new NVP( this.names.type, this.type, 'proxyAuthScheme' ) );
            data.push( new NVP( this.names.address, this.getAddress(), 'proxyAddress' ) );
            data.push( new NVP( this.names.username, this.getUsername(), 'proxyUsername' ) );
            data.push( new NVP( this.names.password, this.password, 'proxyPassword' ) );
        }
        return data;
    }

    this.getData = function() {
        var data = new Array();
        if( this.PROXY_NONE == this.type ) {
            data.push( new NVP( this.names.type, "", 'proxyAuthScheme' ) );
            data.push( new NVP( this.names.address, "", 'proxyAddress' ) );
            data.push( new NVP( this.names.username, "", 'proxyUsername' ) );
            data.push( new NVP( this.names.password, "", 'proxyPassword' ) );
        }
        else if( this.PROXY_NO_AUTH == this.type ) {
            data.push( new NVP( this.names.type, "", 'proxyAuthScheme' ) );
            data.push( new NVP( this.names.address, this.getAddress(), 'proxyAddress' ) );
            data.push( new NVP( this.names.username, "", 'proxyUsername' ) );
            data.push( new NVP( this.names.password, "", 'proxyPassword' ) );
        }
        else if( this.PROXY_BASIC_AUTH == this.type ) {
            data.push( new NVP( this.names.type, "", 'proxyAuthScheme' ) );
            data.push( new NVP( this.names.address, this.getAddress(), 'proxyAddress' ) );
            data.push( new NVP( this.names.username, this.getUsername(), 'proxyUsername' ) );
            data.push( new NVP( this.names.password, this.password, 'proxyPassword' ) );
        }
        else if( this.PROXY_NTLM_AUTH == this.type ) {
            data.push( new NVP( this.names.type, this.type, 'proxyAuthScheme' ) );
            data.push( new NVP( this.names.address, this.getAddress(), 'proxyAddress' ) );
            data.push( new NVP( this.names.username, this.getUsername(), 'proxyUsername' ) );
            data.push( new NVP( this.names.password, this.password, 'proxyPassword' ) );
        }
        return data;
    }
    
    this.show = function() {
        document.getElementById( 'hostnameProxy' ).value = this.hostname;
        document.getElementById( 'portProxy' ).value     = this.port;
        document.getElementById( 'domainProxy' ).value   = this.domain;
        document.getElementById( 'usernameProxy' ).value = this.username;
        document.getElementById( 'passwordProxy' ).value = this.password;
        document.getElementById( 'confirmProxy' ).value  = this.confirm;
    
        if( this.PROXY_NONE == this.type ) {
            document.getElementById( this.PROXY_NONE ).checked = true;
            document.getElementById( this.PROXY_YES ).checked   = false;
        }
        else if( this.PROXY_NO_AUTH == this.type ) {
            document.getElementById( this.PROXY_NONE ).checked   = false;
            document.getElementById( this.PROXY_YES ).checked     = true;
            document.getElementById( this.PROXY_NO_AUTH ).checked    = true;
            document.getElementById( this.PROXY_BASIC_AUTH ).checked = false;
            document.getElementById( this.PROXY_NTLM_AUTH ).checked  = false;
        }
        else if( this.PROXY_BASIC_AUTH == this.type ) {
            document.getElementById( this.PROXY_NONE ).checked   = false;
            document.getElementById( this.PROXY_YES ).checked     = true;
            document.getElementById( this.PROXY_NO_AUTH ).checked    = false;
            document.getElementById( this.PROXY_BASIC_AUTH ).checked = true;
            document.getElementById( this.PROXY_NTLM_AUTH ).checked  = false;
        }
        else if( this.PROXY_NTLM_AUTH == this.type ) {
            document.getElementById( this.PROXY_NONE ).checked   = false;
            document.getElementById( this.PROXY_YES ).checked     = true;
            document.getElementById( this.PROXY_NO_AUTH ).checked    = false;
            document.getElementById( this.PROXY_BASIC_AUTH ).checked = false;
            document.getElementById( this.PROXY_NTLM_AUTH ).checked  = true;
        }
    
        this.proxyChange();
    }
    
    this.hide = function() {
        var e1 = document.getElementById( 'proxyTypeDiv' );
        var e2 = document.getElementById( 'proxyAuthDiv' );
        var e3 = document.getElementById( 'proxyDomainDiv' );
    
        e1.style.visibility = 'hidden';
        e2.style.visibility = 'hidden';
        e3.style.visibility = 'hidden';
    }
    
    /***************************************************************************
     *
     *  additional methods
     */
    this.getAddress = function() {
        if( this.PROXY_NONE == this.type ) {
            return '';
        }
        else if( "" == this.hostname ) {
            return '';
        }
        else if( "" == this.port ) {
            return( this.hostname );
        }
        else {
            return( this.hostname + ':' + this.port );
        }
    }

    this.getUsername = function() {
        if( this.PROXY_NTLM_AUTH == this.type ) {
            return( this.domain + '\\' + this.username );
        }
        else {
            return this.username;
        }
    }

    this.proxyChange = function() {
        var data = this.QSEDialog.getData();
        var e1 = document.getElementById( 'proxyTypeDiv' );
        if( data.proxytype == 'direct' ) {
            e1.style.visibility = 'hidden';
            this.proxyChangeAuth( this.PROXY_NO_AUTH );
        }
        else if( data.proxytype == 'proxy' ) {
            e1.style.visibility = 'visible';
            if( document.getElementById( this.PROXY_NO_AUTH ).checked ) {
                auth = this.PROXY_NO_AUTH;
            }
            else if( document.getElementById( this.PROXY_BASIC_AUTH ).checked ) {
                auth = this.PROXY_BASIC_AUTH;
            }
            else {
                auth = this.PROXY_NTLM_AUTH;
            }
            this.proxyChangeAuth( auth );
        }
    }
    
    this.proxyChangeAuth = function( n ) {
        var e1 = document.getElementById( 'proxyAuthDiv' );
        var e2 = document.getElementById( 'proxyDomainDiv' );
        if( this.PROXY_NO_AUTH == n ) {
            e1.style.visibility = 'hidden';
            e2.style.visibility = 'hidden';
        }
        else if( this.PROXY_BASIC_AUTH == n ) {
            e1.style.visibility = 'visible';
            e2.style.visibility = 'hidden';
        }
        else if( this.PROXY_NTLM_AUTH == n ) {
            e1.style.visibility = 'visible';
            e2.style.visibility = 'visible';
        }
    }
    
    /**
     *  This function registered as an event handler, so it will be called
     *  in the context of the HTML element on which the event occured.  The 
     *  'me' argument to the function will be the module instance object.
     */
    this.onProxyChange = function( event, me ) {
        me.proxyChange();
    }
    
    this.dataIsDirty = function( dlgData ) {
        if( this.hostname != dlgData.hostname ||
            this.port     != dlgData.port ||
            this.domain   != dlgData.domain ||
            this.username != dlgData.username ||
            this.password != dlgData.password ) {
            return true;
        }

        if( document.getElementById( this.PROXY_NONE ).checked == true ) {
            return( this.type != this.PROXY_NONE );
        }
        else if( document.getElementById( this.PROXY_NO_AUTH ).checked == true ) {
            return( this.type != this.PROXY_NO_AUTH );
        }
        else if( document.getElementById( this.PROXY_BASIC_AUTH ).checked == true ) {
            return( this.type != this.PROXY_BASIC_AUTH );
        }
        else if( document.getElementById( this.PROXY_NTLM_AUTH ).checked == true ) {
            return( this.type != this.PROXY_NTLM_AUTH );
        }

        return false;
    }

    this.saveHandler = function( data ) {
        try {
            var ok = true;
            var m = this;
            if( ( data.password == data.confirm ) ) {
                if( m.dataIsDirty( data ) ) {
                    m.hostname   = data.hostname;
                    m.port       = data.port;
                    m.domain     = data.domain;
                    m.username   = data.username;
                    m.password   = data.password;
                    m.confirm    = data.confirm;
                    m.testResult = 'N/A';
                    m.testDate   = 'N/A';
                    m.testDetail = 'N/A';
            
                    if( document.getElementById( m.PROXY_NONE ).checked == true ) {
                        m.type = m.PROXY_NONE;
                        m.testResult = "Ok";
                        m.testDetail = "Successful test.  No proxy server configured";
    
                        var d = new Date();
                        this.testDate = d.toString();
                        delete d;
                    }
                    else if( document.getElementById( m.PROXY_NO_AUTH ).checked == true ) {
                        m.type = m.PROXY_NO_AUTH;
                    }
                    else if( document.getElementById( m.PROXY_BASIC_AUTH ).checked == true ) {
                        m.type = m.PROXY_BASIC_AUTH;
                    }
                    else if( document.getElementById( m.PROXY_NTLM_AUTH ).checked == true ) {
                        m.type = m.PROXY_NTLM_AUTH;
                    }
                }
            }
            else {
                alert( "Passwords do not match" );
                ok = false;
            }

            qse.statusDataChangedEvent.fire( this );        
            m.show();
        }
        catch( e ) {
            alert( 'Caught exception:\n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
        }
        
        return ok;
    }

    this.resetHandler = function( data ) {
        this.show();
    }
    
    this.buildTestBody = function() {
        //
        //  TODO: make this MUCH more robust
        //
        var doc = '';
        doc += '<testConnectionRequest>';
        doc += '<value name="proxyType"     value="' + this.type          + '"/>';
        doc += '<value name="proxyAddress"  value="' + this.getAddress()  + '"/>';
        doc += '<value name="proxyUsername" value="' + this.getUsername() + '"/>';
        doc += '<value name="proxyPassword" value="' + this.password      + '"/>';
        doc += '</testCOnnectionRequest>';
        return doc;
    }

    this.processTestResult = function( xml ) {
        try {
            var ctx = new ExprContext( xmlParse( xml ) );
            this.testResult = 
                xpathEval( '/testConnectionResponse/result', ctx ).stringValue();
            this.testDetail = 
                xpathEval( '/testConnectionResponse/detail', ctx ).stringValue();
            delete ctx;
            
            var d = new Date();
            this.testDate = d.toString();
            delete d;
            
            qse.statusDataChangedEvent.fire( this );
        }
        catch( e ) {
            alert( 'Caught exception:\n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
        }
    }

    this.testHandler = function( data ) {
        if( this.saveHandler( data ) && this.PROXY_NONE != this.type ) {
            try {
                qse.beginWaiting( 'Please wait for the Proxy Server test to complete' );
        
                var callback = {
                    success : function( obj ) {
                        obj.argument.me.processTestResult( obj.responseText );
                        qse.endWaiting();
                    },
                    failure : function( resp ) {
                        qse.endWaiting();
                        alert( 'QSEProxyModule: Test Request failed: ' +
                               'Status: ' + resp.status + '\n' +
                               'Status message: ' + resp.statusText );
                    },
                    argument : { me : this },
                    timeout : qse.getTransactionTimeout()
                }
    
                var postBody = this.buildTestBody();
                var url = "/QSEProxyModule/testConnection";
                YAHOO.util.Connect.initHeader( 'ContentType', 'text/xml' );
                YAHOO.util.Connect.asyncRequest( 'POST', url,
                                                 callback, postBody );
            }
            catch( e ) {
                alert( 'Caught exception: ' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
            }
        }
        else {
            // nothing to do (handled through saveHandler)
        }
    }

    /***************************************************************************
     *
     *  Event listeners
     */
    YAHOO.util.Event.addListener( this.PROXY_NONE, 
                                  'click', this.onProxyChange, this );
    YAHOO.util.Event.addListener( this.PROXY_YES, 
                                  'click', this.onProxyChange, this );
    YAHOO.util.Event.addListener( this.PROXY_NO_AUTH, 
                                  'click', this.onProxyChange, this );
    YAHOO.util.Event.addListener( this.PROXY_BASIC_AUTH, 
                                  'click', this.onProxyChange, this );
    YAHOO.util.Event.addListener( this.PROXY_NTLM_AUTH, 
                                  'click', this.onProxyChange, this );
                                  
    this.init = function( instanceNode ) {
        try {
            var ctx = new ExprContext( instanceNode );
            this.name    = xpathEval( 'name',    ctx ).stringValue();
            this.label   = xpathEval( 'label',   ctx ).stringValue();
            this.group   = xpathEval( 'group',   ctx ).stringValue();
            this.groupDisp = xpathEval( 'groupDisplay',   ctx ).stringValue();
            this.display = xpathEval( 'display', ctx ).stringValue();
            this.markup  = xpathEval( 'markup',  ctx ).stringValue();

            YAHOO.log( 'Proxy init \n' + 
                       '    name    = ' + this.name    + '\n' +
                       '    group   = ' + this.group   + '\n' +
                       '    display = ' + this.display + '\n' +
                       '    markup  = ' + this.markup  + '\n' );

            var nodes = xpathEval( 'tag', ctx );
            if( null != nodes ) {
                var nodeSet = nodes.nodeSetValue();
                for( var i = 0; i < nodeSet.length; ++i ) {
                    var ctx2 = new ExprContext( nodeSet[ i ] );
                    var n  = getAttrValue( 'name',  ctx2 );
                    var p  = getAttrValue( 'purpose',  ctx2 );
                    var v  = getAttrValue( 'value', ctx2 );
                    var t  = getAttrValue( 'type',  ctx2 );
                    var mn = getAttrValue( 'min',   ctx2 );
                    var mx = getAttrValue( 'max',   ctx2 );
                    var vs = '';
                    
                    if( 'proxyAuthScheme' ==  p ) {
                        this.type = v;
                        this.names.type = n;
                    }
                    else if( 'proxyHostname' == p ) {
                        this.hostname = v;
                        this.names.hostname = n;
                    }
                    else if( 'proxyPort' == p ) {
                        this.port = v;
                        this.names.port = n;
                    }
                    else if( 'proxyAddress' == p ) {
                        if( "" != v ) {
                            var tmp = v.split( ':' );
                            this.hostname = tmp[0];
                            this.port = tmp[1];
                        }
                        else {
                            this.hostname = "";
                            this.port = "";
                        }
                        this.names.address = n;
                    }
                    else if( 'proxyUsername' == p ) {
                        var idx = v.indexOf( '\\', 0 );
                        if( -1 == idx ) {
                            this.domain = '';
                            this.username = v;                            
                        }
                        else {
                            this.domain = v.slice( 0, idx );
                            this.username = v.slice( idx + 1 );
                        }
                        this.names.username = n;
                    }
                    else if( 'proxyPassword' == p ) {
                        this.password = v;
                        this.confirm = v;
                        this.names.password = n;
                    }
                    delete ctx2;
                }
                
                //  The proxy type information taken from the sitemap file is
                //  not reliable if the sitemap file has never been edited
                //  by this tool.  We'll adjust the proxy type based on the 
                //  other values that have been set
                if( '' != this.domain ) {
                    this.type = this.PROXY_NTLM_AUTH;
                }
                else if( '' != this.username ) {
                    this.type = this.PROXY_BASIC_AUTH;
                }
                else if( '' != this.hostname ) {
                    this.type = this.PROXY_NO_AUTH;
                }
                else {
                    this.type = this.PROXY_NONE;
                }
            }
            delete ctx;
        }
        catch( e ) {
            alert( 'Caught exception:\n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
        }
    }
    
    YAHOO.log( this.className + '\n' +
               this.name  + '\n' +
    this.label  + '\n' +
    this.group  + '\n' );
    
}

/*******************************************************************************
 *
 *  Inherit everything else from the base module
 */
QSEProxyModule.prototype = QSEBaseModule.prototype;

