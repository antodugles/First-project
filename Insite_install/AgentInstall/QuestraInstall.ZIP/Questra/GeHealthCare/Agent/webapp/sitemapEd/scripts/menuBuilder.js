/*******************************************************************************
 *
 *  Copyright Questra Corp.
 *      All rights reserved
 *
 */

/*******************************************************************************
 *
 */
function MenuBuilder( modules, event ) {
    this.modules    = modules;
    this.event      = event;
}

MenuBuilder.prototype.build = function() {
    var groups  = this.groupMenuItems( this.modules );
    var menu    = this.buildMenu( groups );

    delete groups;
    
    return menu;
}

MenuBuilder.prototype.groupMenuItems = function() {
    YAHOO.log( 'groupMenuItems' );
    var menuGroups = new Array();

    var index = 0;
    for( var i = 0; i < this.modules.length; ++i ) {
        var instances = this.modules[ i ].getInstances();
        for( var j = 0; j < instances.length; ++j ) {
            var m = instances[ j ];
            var groupName = m.getGroupName();
            var groupDisp = m.getGroupDisp();

            var found = false;
            for( var name in menuGroups ) {
                if( name == groupName ) {
                    found = true;
                    break;
                }
            }

            if( !found ) {
                menuGroups[ groupName ] = new Array();
            }

            m.QSEMenuIndex = index++;
            menuGroups[ groupName ].push( {
                text: '<span id="QSE' + m.QSEMenuIndex + '"></span>' + m.getLabel(),
                url: 'javascript:qse.showModule(' + m.QSEMenuIndex + ')',
                QSEDisplay: m.display
            } );
            menuGroups[ groupName ].QSEDisplay = groupDisp;
            menuGroups[ groupName ].QSEGroupName = groupName;

            YAHOO.log( 'groupMenuItems - ' + groupName );            
            YAHOO.log( 'groupMenuItems - ' + m.getLabel() );
            YAHOO.log( 'groupMenuItems - ' + m.QSEMenuIndex );
        }
    }
    
    //  we need a sortable array
    var groups = new Array();
    for( var name in menuGroups ) {
        groups.push( menuGroups[ name ] );
    }
    groups.sort( this.sort );
    delete menuGroups;

    return groups;
}

MenuBuilder.prototype.buildMenu = function( groups ) {
    YAHOO.log( 'buildMenu' );
    var menu = new YAHOO.widget.Menu( "mainMenu", { position: 'static' } );
    var groupId = 0;
    
    for( var i = 0; i < groups.length; ++i ) {
        var items = groups[ i ];
        items.sort( this.sort );
        for( var j = 0; j < items.length; ++j ) {
            var item = items[ j ];
            menu.addItem( item, groupId );
        }

        menu.setItemGroupTitle( items.QSEGroupName, groupId );
        ++groupId;
    }
    
    return menu;
}

MenuBuilder.prototype.sort = function( a, b ) {
    if( a.QSEDisplay && b.QSEDisplay ) {
        return( a.QSEDisplay - b.QSEDisplay );
    }
    else {
        return( 0 );
    }
}
