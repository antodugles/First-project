/*******************************************************************************
 *
 *	Copyright Questra Corp.
 *      All rights reserved
 *
 */

/*******************************************************************************
 *
 *  Initialization
 *
 *  When the DOM is ready, this function will invoke the initialization
 *  method on the server.  The response should be a list of JavaScript
 *  files that should be loaded, each representing a 'module' of this UI.
 *  As each file is loaded, it should register itself through the 
 *  YAHOO.QSE.RegisterModule() method.  Once each module is loaded, the
 *  module will be 'plugged in' to the main framework.
 *
 */
qse = null;
var qseLogReader = null;

(function() {
    YAHOO.util.Event.onDOMReady(
        function() {
            try {
//                qseLogReader = new YAHOO.widget.LogReader();
                YAHOO.log( "Starting" );

                var commitButton = new YAHOO.widget.Button( "commitButton" );
                var logoutButton = new YAHOO.widget.Button( "logoutButton" );
                var statusButton = new YAHOO.widget.Button( "networkStatus" );

                var handleLogin = function() {
                    if( this.submit() ) {
                        qse.beginWaiting( 'Please wait for initialization' );
                    }
                }

                var handleLoginSuccess = function( resp ) {
                    if( resp.responseText == 'login' ) {
                        qse.endWaiting();
                        loginDialog.hide();
                        document.getElementById( 'doc' ).style.visibility = 'visible';
                        qse.initialize();
                    }
                    else {
                        alert( resp.responseText );
                        loginDialog.show();
                        qse.endWaiting();
                    }
                }

                var handleLoginFailure = function( resp ) {
                    qse.endWaiting();
                    alert( "Html Server failed with status = " + resp.status );
                    loginDialog.show();
                }

                var loginDialog =
                    new YAHOO.widget.Dialog( "loginDialog", {
                        width :               "340px",
                        fixedcenter :         true,
                        visible :             false,
                        close:                false,
                        constraintoviewport : true,
                        draggable :           false,
                        modal :               true,
                        buttons : [ { 
                            text:"Login", 
                            handler: handleLogin, 
                            isDefault: true } ]
                    } );

                var kl = new YAHOO.util.KeyListener( "loginDialog", { keys: 13 },
                                                     { fn: handleLogin,
                                                       scope: loginDialog,
                                                       correctScope: true } );
                loginDialog.cfg.queueProperty( "keylisteners", kl );
                loginDialog.callback = { success: handleLoginSuccess,
                                         failure: handleLoginFailure };
                loginDialog.validate = function() {
                    var data = this.getData();
                    if( data.username == "" || data.password == "" ) {
                        alert( "Please enter a valid username and password." );
                        return false;
                    } 
                    else { 
                        return true;
                    }
                };
                loginDialog.render( document.body );
                loginDialog.show();
                
                qse = new QSE( loginDialog );
            }
            catch( e ) {
                alert( e.message );
            }
        }
    );
})();

/**
 *
 */
function QSE( loginDialog ) {
    YAHOO.log( "Constructing qse" );

    //  container for the modules
    this.moduleContainers = new Array();
    this.statusModules = new Array();
    this.statusData = new Array();
    this.statusTooltips = new Array();
    this.loginDialog = loginDialog;
    this.LOGIN_TIMEOUT = 300000;     // five-minutes
    this.waiting = false;
    this.initialized = false;

    //  event handlers
    YAHOO.util.Event.addListener( 
        'commitButton', 
        'click',
        function( event ) {
            qse.commitChanges( event );
        }
    );

    YAHOO.util.Event.addListener( 
        'logoutButton', 
        'click',
        function( event ) {
            qse.logout( event, false );
        }
    );

    //  custom events
    this.registrationDoneEvent = 
        new YAHOO.util.CustomEvent( 'regDoneEvent', this );
    this.statusDataChangedEvent = 
        new YAHOO.util.CustomEvent( 'statusChangedEvent', this );
    this.buildUIDoneEvent = 
        new YAHOO.util.CustomEvent( 'buildUIDoneEvent', this );
    this.markupDoneEvent = 
        new YAHOO.util.CustomEvent( 'markupDoneEvent', this );
}

QSE.prototype.onRegistrationDoneEvent = function( type, args, me ) {
    YAHOO.log( 'onRegistrationDoneEvent ' + args );
    var c = this.findContainer( args );
    c.markRegistrationDone();
    c.getMarkup();
    this.buildUI();
}

QSE.prototype.onMarkupDoneEvent = function( type, args, me ) {
    YAHOO.log( 'onMarkupDoneEvent ' + args );
    this.buildUI();
}

QSE.prototype.onStatusDataChangedEvent = function( type, args, me ) {
    this.statusDataChanged();
}

QSE.prototype.onBuildUIDoneEvent = function( type, args, me ) {
    this.endWaiting();
    this.statusDataChangedEvent.fire( this );
}

//
//  initialization functions
//
//  called when the initialization message to 
//  the server recieves a success response
QSE.prototype.initializeSuccess = function( response ) {
    try {
        YAHOO.log( response.responseText );

        this.registrationDoneEvent.subscribe( this.onRegistrationDoneEvent, this );
        this.statusDataChangedEvent.subscribe( this.onStatusDataChangedEvent, this );
        this.buildUIDoneEvent.subscribe( this.onBuildUIDoneEvent, this );
        this.markupDoneEvent.subscribe( this.onMarkupDoneEvent, this );

        //  create the module containers
        this.createModuleContainers( response.responseText );

        //  load each module script file
        for( var i = 0; i < this.moduleContainers.length; ++i ) {
            this.moduleContainers[ i ].loadScript();
        }
        
        this.initialized = true;
        this.beginLogoutTimer();
        YAHOO.util.Event.addListener( document.body, 'click', 
                                      this.beginLogoutTimer, this, true);
        YAHOO.util.Event.addListener( document.body, 'keypress',
                                      this.beginLogoutTimer, this, true);
    }
    catch( e ) {
        alert( 'Caught exception: \n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
}

//  called when the initialization message to
//  the server receives a failure response
QSE.prototype.initializeFailure = function( response ) {
    this.endWaiting();
    alert( 'Application Initialization Failed\n\n' +
           'Status code: ' + response.status + '\n' +
           'Status message: ' + response.statusText );
}

//  main intialization entry point
QSE.prototype.initialize = function() {
    if( !this.initialized ) {
        var callback = {
            success : function( resp ) { qse.initializeSuccess( resp ) },
            failure : function( resp ) { qse.initializeFailure( resp ) },
            argument: { me : this },
            timeout: qse.getTransactionTimeout()
        }
    
        try {
            var url = '/initialize';
            var postBody = '';
            YAHOO.util.Connect.initHeader( 'ContentType', 'text/xml' );
            var conn = YAHOO.util.Connect.asyncRequest( 'POST', url,
                                                        callback, postBody );
        }
        catch( e ) {
            alert( 'Caught exception: \n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
        }
    }
}

QSE.prototype.createModuleContainers = function( text ) {
    try {
        var ctx = new ExprContext( xmlParse( text ) );
        var nodes = xpathEval( '/initializeResponse/moduleContainer', ctx );
        if( null != nodes ) {
            var nodeSet = nodes.nodeSetValue();
            for( var i = 0; i < nodeSet.length; ++i ) {
                var ctx2 = new ExprContext( nodeSet[ i ] );
                var n = xpathEval( 'className', ctx2 ).stringValue();
                var s = xpathEval( 'scriptFile', ctx2 ).stringValue();
                this.moduleContainers.push( new ModuleContainer( n, s ) );
                delete ctx2;
            }
        }
        else {
            alert( 'No moduleContainers found during initialization' );
        }
        delete ctx;
    }
    catch( e ) {
        alert( 'Caught exception: \n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
}

QSE.prototype.registerModuleInstance = function( instance ) {
    try {
        var name = instance.getClassName();
        var c = this.findContainer( name );

        YAHOO.log( 'registerModuleInstance - containerName = ' + name );
        
        if( null != c ) {
            c.addInstance( instance );
        }
        else {
            alert( 'No moduleContainer found for ' +
                   'instance with className = ' + name );
        }
    }
    catch( e ) {
        alert( 'Caught exception: \n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
}

QSE.prototype.registerStatusModule = function( instance ) {
    this.statusModules.push( instance );
}

QSE.prototype.findContainer = function( name ) {
    for( var i = 0; i < this.moduleContainers.length; ++i ) {
        var m = this.moduleContainers[ i ];
        if( m.getClassName() == name ) {
            return m;
        }
    }
    
    return null;
}

QSE.prototype.buildUI = function() {
    try {
        for( var i = 0; i < this.moduleContainers.length; ++i ) {
            var c = this.moduleContainers[ i ];
            if( !c.isRegistrationDone() ) {
                YAHOO.log( 'Registration of module ' + c.getClassName() + ' is not done' );
                return;
            }
            else if( !c.isMarkupDone() ) {
                YAHOO.log( 'Markup of module ' + c.getClassName() + ' is not done' );
                return;
            }
        }

        this.updateMainMenu();
        this.updateEditModules();
        this.buildUIDoneEvent.fire( this );
    }
    catch( e ) {
        alert( 'Caught exception: \n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
}

QSE.prototype.getMarkup = function( m ) {
    try {
        var callback = {
            success : function( resp ) {
                resp.argument.module.QSEMarkupBody = resp.responseText;
            },
            failure : function( response ) {
                alert( 'Get Markup Request Failed\n\n' +
                       'Status code: ' + response.status + '\n' +
                       'Status message: ' + response.statusText );
            },
            argument : { module : m },
            timeout: qse.getTransactionTimeout()
        }

        var url = m.getMarkup();
        YAHOO.util.Connect.initHeader( 'ContentType', 'text/xml' );
        YAHOO.util.Connect.asyncRequest( 'GET', url, callback );
    }
    catch( e ) {
        alert( 'Caught exception: ' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
}

QSE.prototype.updateMainMenu = function() {
    try {
        delete this.menu;

        YAHOO.log( 'Updating the main menu' );

        var builder = new MenuBuilder( this.moduleContainers );
        this.menu = builder.build();

        YAHOO.log( 'Rendering the main menu' );

        this.menu.showEvent.subscribe( function () { this.focus(); } );
        this.menu.render( "menu" );

        YAHOO.log( 'Done building menu' );
    }
    catch( e ) {
        alert( 'Caught exception: \n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
    finally {
        delete builder;
    }
}

QSE.prototype.updateEditModules = function() {
    try {
        var maxHeight = 0;
        for( var i = 0; i < this.moduleContainers.length; ++i ) {
            var instances = this.moduleContainers[ i ].getInstances();
            for( var j = 0; j < instances.length; ++j ) {
                var m = instances[ j ];
                var name = m.getModuleName();
                
                YAHOO.log( "updateEditModules - " + name );

                var e = document.getElementById( "mainContentArea" );
                var d = document.createElement( "div" );
                d.setAttribute( "id", name );
                e.appendChild( d );

                var dlg = new YAHOO.widget.Dialog( name, {
                    visible:    false,
                    width:      "565px",
                    close:      false,
                    zindex:     0,
                    draggable:  false,
                    underlay:   "none",
                    postmethod: "none",
                    buttons:    m.getButtons()
                });

                dlg.setHeader( m.getLabel() );
                if( m.QSEMarkup ) {
                    dlg.setBody( m.QSEMarkup );
                }
                else {
                    dlg.setBody( m.getMarkup() );
                }
                dlg.render();
                m.QSEDialog = dlg;
                dlg.QSEParentModule = m;

                maxHeight = d.offsetHeight > maxHeight ? d.offsetHeight : maxHeight;
            }
        }

        //  set the height of the main content area
        var e = document.getElementById( "mainContentArea" );
        e.style.height = maxHeight*1.1 + "px";
    }
    catch( e ) {
       alert( 'Caught exception:\n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
}

QSE.prototype.showModule = function( idx ) {
    try {
        for( var i = 0; i < this.moduleContainers.length; ++i ) {
            var instances = this.moduleContainers[ i ].getInstances();
            for( var j = 0; j < instances.length; ++j ) {
                var m = instances[ j ];
                if( idx == m.QSEMenuIndex ) {
                    m.show();
                    m.QSEDialog.show();
                }
                else {
                    m.hide();
                    m.QSEDialog.hide();
                }
            }
        }
    }
    catch( e ) {
        alert( 'Caught exception: ' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
}

QSE.prototype.processCommitSuccess = function( xml ) {
    try {
        //  parse the error, commit and restart messages
        var ctx = new ExprContext( xmlParse( xml ) );
        var emsg = xpathEval( '/commitResponse/errorMessage', ctx );
        var smsg = xpathEval( '/commitResponse/saveMessage', ctx );
        var rmsg = xpathEval( '/commitResponse/restartMessage', ctx );
        delete ctx;

        if( "" != emsg.stringValue() ) {
            // there was an error
            alert( emsg.stringValue() );
            qse.endWaiting();
        }
        else {
            //  no error
            alert( smsg.stringValue() + '\n' + rmsg.stringValue() );
            qse.logout( null, false );
        }
    }
    catch( e ) {
        alert( 'Caught exception: \n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
}

QSE.prototype.commitChanges = function( event ) {
    this.beginWaiting( 'Please wait while commiting changes' );

    var callback = {
        success : function( obj ) {
            qse.processCommitSuccess( obj.responseText );
        },
        failure : function( response ) {
            qse.endWaiting();
            alert( 'Commit Request Failed\n\n' +
                   'Status code: ' + response.status + '\n' +
                   'Status message: ' + response.statusText );
        },
        timeout: qse.getTransactionTimeout()
    }

    try {
        var postBody = new CommitRequest();

        //  extract the commitable data from each module
        for( var i = 0; i < this.moduleContainers.length; ++i ) {
            var instances = this.moduleContainers[ i ].getInstances();
            for( var j = 0; j < instances.length; ++j ) {
                var m = instances[ j ];
                var tags = m.getData();
                for( var k = 0; k < tags.length; ++k ) {
                    postBody.addTag( tags[ k ] );
                }
                delete tags;
            }
        }
        
        YAHOO.log( postBody.toString() );

        var url = "/commitChanges";
        YAHOO.util.Connect.initHeader( 'ContentType', 'text/xml' );
        var conn = 
            YAHOO.util.Connect.asyncRequest( 'POST', url, 
                                             callback, postBody.toString() );
    }
    catch( e ) {
        alert( 'Caught exception: ' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
    finally {
        delete postBody;
    }
}

QSE.prototype.statusDataChanged = function() {
    try {
        this.updateStatusDialog();
        this.updateStatusIndicator();
    }
    catch( e ) {
        alert( 'Caught exception: ' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
}

QSE.prototype.getDataByModuleName = function( name ) {
    var data = null;
    for( var i = 0; i < this.moduleContainers.length; ++i ) {
        data = this.moduleContainers[ i ].getDataByModuleName( name );
        if( null != data ) {
            return data;
        }
    }
    return data;
}

QSE.prototype.updateStatusIndicator = function() {
    for( var i = 0; i < this.moduleContainers.length; ++i ) {
        var inst = this.moduleContainers[ i ].getInstances();
        for( var j = 0; j < inst.length; ++j ) {
            var m = inst[ j ];
            var s = m.getStatus().toLowerCase();
            var el = document.getElementById( 'QSE' + m.QSEMenuIndex );
            if( 'ok' == s ) {
                el.innerHTML = '<img src="/images/glassygreen.png" height="12" width="12"/>';
            }
            else if( 'n/a' == s ) {
                el.innerHTML = '<img src="/images/glassygrey.png" height="12" width="12"/>';
            }
            else {
                el.innerHTML = '<img src="/images/glassyred.png" height="12" width="12"/>';
            }
        }
    }
}

QSE.prototype.updateStatusDataTable = function() {
    try {
        this.statusData.splice( 0, this.statusData.length );
        this.statusTooltips.splice( 0, this.statusTooltips.length );
    
        for( var i = 0; i < this.statusModules.length; ++i ) {
            var m = this.statusModules[ i ];
            this.statusData.push( { 
                label:  m.getStatusLabel(),
                desc:   m.getStatusDescription(),
                time:   m.getStatusDate(),
                result: '<div id="QSE' + m.getStatusLabel() + '">' + 
                                         m.getTestResult() + '</div>'
            } );

            this.statusTooltips.push( 
                new YAHOO.widget.Tooltip( 'statusTooltip' + i, {
                    context:          'QSE' + m.getStatusLabel(),
                    text:             m.getStatusDetail(),
                    showDelay:        500,
                    autodismissdelay: 50000,
                    zIndex:           20
                } )
            );
        }
    
        if( this.statusDataTable == null ) {
            this.statusDataSource = 
                new YAHOO.util.DataSource( this.statusData );
            this.statusDataSource.responseType = YAHOO.util.DataSource.TYPE_JSARRAY;
            this.statusDataSource.responseSchema = {
                fields: [ "label", "desc", "time", "result" ]
            };
    
            var statusColumnDefs = [
                { key: "label",  label: "" },
                { key: "desc",   label: "Description" },
                { key: "time",   label: "Date/Time" },
                { key: "result", label: "Result" } 
            ];
    
            this.statusDataTable = 
                new YAHOO.widget.DataTable( "statusTableContainer", 
                    statusColumnDefs, this.statusDataSource );
        }
        else {
            this.statusDataTable.initializeTable( this.statusData );
        }
    }
    catch( e ) {
        alert( 'Caught exception: \n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );        
    }
}

QSE.prototype.updateStatusDialog = function() {
    try {
        if( this.statusDialog == null ) {
            this.statusDialog = new YAHOO.widget.Dialog( "statusContainer", {
                //  NOTE:   IE 7 doesn't render this correctly 
                //          unless a width is specified.  Even with 
                //          the width specified, IE 7 is a great 
                //          disapointment with respect to it's 
                //          rendering of this dialog.
                width: "675px",
                visible: false,
                zindex: 5,
                constraintoviewport: true
            } );
    
            YAHOO.util.Event.addListener( "networkStatus", "click", 
                this.statusDialog.show, this.statusDialog, true );
    
            this.statusDialog.setHeader( "Status" );
            this.statusDialog.setBody( '<div id="statusTableContainer"></div>' );
            this.statusDialog.render();
        }
    
        this.updateStatusDataTable();
    }
    catch( e ) {
        alert( 'Caught exception: \n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );        
    }
}

QSE.prototype.beginWaiting = function( msg ) {
    if( this.waiting == false ) {
        if( null == this.waitPanel ) {
            this.waitPanel = 
                new YAHOO.widget.Panel( "wait", {
                    width:          "240px", 
                    fixedcenter:    true, 
                    close:          false, 
                    draggable:      false, 
                    modal:          true,
                    visible:        false,
                    zindex:         10,
                    effect: {
                        effect:     YAHOO.widget.ContainerEffect.FADE,
                        duration:   0.25
                    } 
                } );
        }
        
        this.waitPanel.setBody( msg );
        this.waitPanel.render( document.body );
        this.waitPanel.show();
        this.waiting = true;
    }
}

QSE.prototype.endWaiting = function() {
    this.waitPanel.hide();
    this.waiting = false;
}

QSE.prototype.beginLogoutTimer = function() {
    YAHOO.log( 'beginLogoutTimer' );
    window.clearTimeout( this.logoutTimerId );
    this.logoutTimerId = 
        window.setTimeout( "qse.logout( null, true )", this.LOGIN_TIMEOUT );
}

QSE.prototype.logout = function( event, timeout ) {
    if( timeout ) {
        this.beginWaiting( '' );
        alert( 'Your login has ended due to inactivity' );
    }
    parent.location.href = '/';
}

QSE.prototype.getTransactionTimeout = function() {
    return 180000; // three minute timeout on all transactions
}
