/*******************************************************************************
 *
 *  Copyright Questra Corp.
 *      All rights reserved
 *
 */

/**********************************************************************
 *
 */
function ModuleContainer( name, scriptURL ) {
    YAHOO.log( name + '\n' + scriptURL );
    this.className          = name;
    this.scriptURL          = scriptURL;
    this.instances          = new Array();
    this.registrationDone   = false;
}

ModuleContainer.prototype.loadScript = function() {
    try {
        var elem = document.createElement( 'script' );
        elem.src = this.scriptURL;
        elem.type = 'text/javascript';
        document.getElementsByTagName( 'head' )[0].appendChild( elem );
    }
    catch( e ) {
        alert( 'Caught exception: \n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
}

ModuleContainer.prototype.addInstance = function( instance ) {
    YAHOO.log( '\n\n\naddInstance - \n' + 
               '   className - ' + instance.getClassName() + '\n' +
               '   moduleName - ' + instance.getModuleName() + '\n' +
               '   label - ' + instance.getLabel() + '\n' );
    instance.QSEMarkupDone = false;
    this.instances.push( instance );
}

ModuleContainer.prototype.markRegistrationDone = function() {
    this.registrationDone = true;
}

ModuleContainer.prototype.isRegistrationDone = function() {
    return this.registrationDone;
}

ModuleContainer.prototype.getInstances = function() {
    return this.instances;
}

ModuleContainer.prototype.getClassName = function() {
    return this.className;
}

ModuleContainer.prototype.isMarkupDone = function() {
    for( var i = 0; i < this.instances.length; ++i ) {
        var m = this.instances[ i ];
        if( false == m.QSEMarkupDone ) {
            return false;
        }
    }

    return true;
}

ModuleContainer.prototype.getMarkup = function() {       
    try {
        for( var i = 0; i < this.instances.length; ++i ) {
            var m = this.instances[ i ];
            if( '/' == m.getMarkup().slice( 0, 1 ) && false == m.QSEMarkupDone ) {
                var callback = {
                    success : function( resp ) { 
                        YAHOO.log( 'getMarkup ' + resp.responseText );
                        resp.argument.module.QSEMarkup = resp.responseText;
                        resp.argument.module.QSEMarkupDone = true;
                        qse.markupDoneEvent.fire( resp.argument.module );
                    },
                    failure : function( resp ) { 
                        alert( 'Failed to get markup with server error code: ' + resp.status );
                    },
                    argument: { module: m }
               }
               
               var url = m.getMarkup();
               YAHOO.util.Connect.initHeader( 'ContentType', 'text/xml' );
               YAHOO.util.Connect.asyncRequest( 'GET', url, callback );
            }
            else {
                m.QSEMarkupDone = true;
            }
        }
    }
    catch( e ) {
        alert( 'Caught exception: \n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
    }
}

ModuleContainer.prototype.getDataByModuleName = function( name ) {
    for( var i = 0; this.instances.length; ++i ) {
        var m = this.instances[ i ];
        if( m.getClassName() == name ) {
            return m.getTestData();
        }
    }
    return null;
}
