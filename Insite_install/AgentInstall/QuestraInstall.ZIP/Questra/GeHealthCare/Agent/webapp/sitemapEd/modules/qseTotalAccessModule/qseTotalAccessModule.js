/*******************************************************************************
 *
 *  Copyright Questra Corp.
 *      All rights reserved
 *
 */
/*******************************************************************************
 *
 */
(function() {
    YAHOO.util.Event.onDOMReady(
        function() {
            try {
                var callback = {
                    success : function( resp ) {
                        
        
                        YAHOO.log( '\n\nTA module\n' +
                                   resp.status + '\n' +
                                   resp.responseText
                                 );
                                 
                        var ctx = new ExprContext( xmlParse( resp.responseText ) );
                        var nodes = xpathEval( '/initializeResponse/instance', ctx );
                        
                        YAHOO.log( nodes.toString() );
                        
                        if( null != nodes ) {
                            var nodeSet = nodes.nodeSetValue();
                            YAHOO.log( 'Generating module ' +  nodeSet.length + ' instances' );
                            for( var i = 0; i < nodeSet.length; ++i ) {
                                var m = new QSETotalAccessModule();
                                m.init( nodeSet[ i ] );
                                qse.registerModuleInstance( m );
                                qse.registerStatusModule( m );
                            }
                        }
                        else {
                            alert( 'No moduleContainers found during initialization' );
                        }
                        delete ctx;
                        YAHOO.log( 'Registration done event firing' );
                        qse.registrationDoneEvent.fire( m.getClassName() );
                    },
                    failure : function( resp ) {
                        alert( 'QSETotalAccessModule: Initialization failed: ' +
                               'Status: ' + resp.status + '\n' +
                               'Status message: ' + resp.statusText );
                    },
                    timeout: qse.getTransactionTimeout()
                }
        
                var postBody = '';
                var url = "/QSETotalAccessModule/initialize";
                YAHOO.util.Connect.initHeader( 'ContentType', 'text/xml' );
                YAHOO.util.Connect.asyncRequest( 'POST', url,
                                                 callback, postBody );
            }
            catch( e ) {
                alert( 'Caught exception: ' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
            }
        }
    );
})();

/**
 *  The saveHandler_g, resetHandler_g and testHandler_g functions are in the
 *  global scope because they are registered as event handlers on the dialog
 *  buttons.  As a result, the functions will always be called in the scope of 
 *  the dialog ( 'this' will be the dialog object ).  The QSEParentModule
 *  property of the dialog will be the module object and can be used to get
 *  into the proper scope.
 */
saveHandler_g = function( event ) {
    this.QSEParentModule.saveHandler( this.getData() );
}

resetHandler_g = function( event ) {
    this.QSEParentModule.resetHandler( this.getData() );
}

testHandler_g = function( event ) {
    this.QSEParentModule.testHandler( this.getData() );
}

/*******************************************************************************
 *
 *  
 */
function QSETotalAccessModule() {
    /**
     *  data used by the UI framework
     */
    this.className      = 'QSETotalAccessModule';
    this.name       = '';
    this.label      = '';
    this.group      = '';
    this.buttons    = [
        { text: "Test Connection",  handler: testHandler_g },
        { text: "Ok",               handler: saveHandler_g, isdefault: true },
        { text: "Reset",            handler: resetHandler_g }
    ];
    
    /**
     *  User editable data
     */
    this.enabled        = true;
    this.protocol       = '';
    this.hostname       = '';
    this.port           = '';
    this.names          = new Array();

    this.testDate       = 'N/A';
    this.testResult     = 'N/A';
    this.testDetail     = 'N/A';


    /***************************************************************************
     *
     * override these methods
     */
    this.show = function() {
        document.getElementById( 'protocolTotalAccess' ).value = this.protocol;
        document.getElementById( 'hostnameTotalAccess' ).value = this.hostname;
        document.getElementById( 'portTotalAccess' ).value     = this.port;
        document.getElementById( 'enabledTotalAccess' ).checked = this.enabled;
        document.getElementById( 'disabledTotalAccess' ).checked = !this.enabled;

        var el = document.getElementById( 'tableTotalAccess' );
        if( this.enabled ) {
            el.style.visibility = 'visible';
        }
        else {
            el.style.visibility = 'hidden';
        }
    }

    this.hide = function() {
        var el = document.getElementById( 'tableTotalAccess' );
        el.style.visibility = 'hidden';
    }

    this.getData = function() {
        var data = new Array();
        data.push( new NVP( this.names.address, this.getAddress(), 'taAddress' ) );
        return data;
    }

    /***************************************************************************
     *
     *  Additions to the base interface
     */
    this.getStatus = function() {
        if( this.enabled ) {
            return this.testResult;
        }
        else {
            return "Ok";
        }
    }

    this.getStatusLabel = function() {
        return this.label;
    }
    
    this.getStatusDescription = function() {
        return this.getAddress();
    }

    this.getStatusDate = function() {
        return this.testDate;
    }
    
    this.getTestResult = function() {
        if( this.enabled ) {
            return this.testResult;
        }
        else {
            return "Ok";
        }
    }
    
    this.getStatusDetail = function() {
        return this.testDetail;
    }

    this.getAddress = function() {
        if( !this.enabled || "" == this.hostname || "" == this.port ) {
            return( "" );
        }
        else {
            return( this.protocol + '://' + this.hostname + ':' + this.port );
        }
    }

    this.dataIsDirty = function( dlgData ) {
        if( this.protocol != dlgData.protocol.toString() ||
            this.hostname != dlgData.hostname ||
            this.port != dlgData.port ) {
            return true;
        }

        if( document.getElementById( 'enabledTotalAccess' ).checked == true ) {
            return( this.enabled != true );
        }
        else {
            return( this.enabled != false );
        }

        return false;
    }

    /**
     *
     */
    this.saveHandler = function( data ) {
        try {
            var m = this;

            if( m.dataIsDirty( data ) ) {
                m.protocol   = data.protocol;
                m.hostname   = data.hostname;
                m.port       = data.port;
                m.enabled    = document.getElementById( 'enabledTotalAccess' ).checked;
                if( m.enabled ) {
                    m.testResult = 'N/A';
                    m.testDetail = 'N/A';
                    m.testDate = '';
                }
                else {
                    m.testResult = 'Ok';
                    m.testDetail = 'TotalAccess is disabled';
                    m.testDate = '';
                }
    
                qse.statusDataChangedEvent.fire( this );        
                m.show();
            }
        }
        catch( e ) {
            alert( 'Caught exception:\n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
        }
    }

    this.resetHandler = function( event ) {
        this.show();
    }

    this.buildTestBody = function() {
        var doc = new XDocument();
        var root = doc.createElement( 'testConnectionRequest' );
        var val = doc.createElement( 'value' );
        val.setAttribute( 'name', 'taAddress' );
        val.setAttribute( 'value', this.getAddress() );
        root.appendChild( val );

        var proxyData = qse.getDataByModuleName( 'QSEProxyModule' );
        for( var i = 0; i < proxyData.length; ++i ) {
            var val = doc.createElement( 'value' );
            val.setAttribute( 'name', proxyData[ i ].purpose );
            val.setAttribute( 'value', proxyData[ i ].value );
            root.appendChild( val );
        }
        
        doc.appendChild( root );
        var txt = xmlText( doc );
        delete doc;
        return txt;
    }
    
    this.processTestResult = function( xml ) {
        try {
            var ctx = new ExprContext( xmlParse( xml ) );
            this.testResult = 
                xpathEval( '/testConnectionResponse/result', ctx ).stringValue();
            this.testDetail = 
                xpathEval( '/testConnectionResponse/detail', ctx ).stringValue();
            delete ctx;
            
            var d = new Date();
            this.testDate = d.toString();
            delete d;
            
            qse.statusDataChangedEvent.fire( this );
        }
        catch( e ) {
            alert( 'Caught exception:\n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
        }
    }

    this.testHandler = function( data) {
        try {
            this.saveHandler( data );
            if( this.enabled ) {
                qse.beginWaiting( 'Please wait for the TotalAccess server test to complete' );
        
                var callback = {
                    success : function( obj ) {
                        obj.argument.me.processTestResult( obj.responseText );
                        qse.endWaiting();
                    },
                    failure : function( resp ) {
                        qse.endWaiting();
                        alert( 'QSETotalAccessModule: Test Request failed: ' +
                               'Status: ' + resp.status + '\n' +
                               'Status message: ' + resp.statusText );
                    },
                    argument : { me : this },
                    timeout: qse.getTransactionTimeout()
                }
    
                var postBody = this.buildTestBody();
                YAHOO.log( 'TA Test -- \n' + postBody );
                var url = "/QSETotalAccessModule/testConnection";
                YAHOO.util.Connect.initHeader( 'ContentType', 'text/xml' );
                YAHOO.util.Connect.asyncRequest( 'POST', url,
                                                 callback, postBody );
            }
            else {
                alert( 'The TotalAccess feature is currently disabled' );

                this.testResult = "Ok";
                this.testDetail = "TotalAccess is disabled";
                var d = new Date();
                this.testDate = d.toString();
                delete d;
            
                qse.statusDataChangedEvent.fire( this );
            }
        }
        catch( e ) {
            alert( 'Caught exception: ' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
        }
    }

    this.onEnableOrDisable = function( event, me ) {
        var el = document.getElementById( 'tableTotalAccess' );
        if( document.getElementById( 'enabledTotalAccess' ).checked ) {
            el.style.visibility = 'visible';
        }
        else {
            el.style.visibility = 'hidden';
        }
    }

    /***************************************************************************
     *
     *  Event listeners
     */
    YAHOO.util.Event.addListener( 'enabledTotalAccess', 
                                  'click', this.onEnableOrDisable, this );
    YAHOO.util.Event.addListener( 'disabledTotalAccess', 
                                  'click', this.onEnableOrDisable, this );

    this.init = function( instanceNode ) {
        try {
            var ctx = new ExprContext( instanceNode );
            this.name    = xpathEval( 'name',    ctx ).stringValue();
            this.label   = xpathEval( 'label',   ctx ).stringValue();
            this.group   = xpathEval( 'group',   ctx ).stringValue();
            this.groupDisp = xpathEval( 'groupDisplay',   ctx ).stringValue();
            this.display = xpathEval( 'display', ctx ).stringValue();
            this.markup  = xpathEval( 'markup',  ctx ).stringValue();

            YAHOO.log( 'TA init \n' + 
                       '    name    = ' + this.name    + '\n' +
                       '    group   = ' + this.group   + '\n' +
                       '    display = ' + this.display + '\n' +
                       '    markup  = ' + this.markup  + '\n' );

            var nodes = xpathEval( 'tag', ctx );
            if( null != nodes ) {
                var nodeSet = nodes.nodeSetValue();
                for( var i = 0; i < nodeSet.length; ++i ) {
                    var ctx2 = new ExprContext( nodeSet[ i ] );
                    var n  = getAttrValue( 'name',  ctx2 );
                    var p  = getAttrValue( 'purpose', ctx2 );
                    var v  = getAttrValue( 'value', ctx2 );
                    var t  = getAttrValue( 'type',  ctx2 );
                    var mn = getAttrValue( 'min',   ctx2 );
                    var mx = getAttrValue( 'max',   ctx2 );
                    var vs = '';
                    
                    if( 'taAddress' == p ) {
                        if( "" == v ) {
                            this.protocol = "";
                            this.hostname = "";
                            this.port     = "";
                            this.names.address = n;
                            this.enabled  = false;
                        }
                        else {
                            var s = v.split( ':', 3 );
                            this.protocol = s[ 0 ];
                            this.hostname = s[ 1 ].replace( '//', '' );
                            this.port     = s[ 2 ];
                            this.names.address = n;
                            this.enabled  = true;
                        }
                    }
                    delete ctx2;
                }
            }
            delete ctx;
        }
        catch( e ) {
            alert( 'Caught exception:\n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
        }
    }
    YAHOO.log( this.className + '\n' +
               this.name  + '\n' +
    this.label  + '\n' +
    this.group  + '\n' );
}

/*******************************************************************************
 *
 *  Inherit everything else from the base module
 */
QSETotalAccessModule.prototype = QSEBaseModule.prototype;
