/*******************************************************************************
 *
 *  Copyright Questra Corp.
 *      All rights reserved
 *
 */

/*******************************************************************************
 *
 */
(function() {
    YAHOO.util.Event.onDOMReady(
        function() {
            try {
                var callback = {
                    success : function( resp ) {
                        
        
                        YAHOO.log( '\n\nGeneric module\n' +
                                   resp.status + '\n' +
                                   resp.responseText
                                 );
                                 
                        var ctx = new ExprContext( xmlParse( resp.responseText ) );
                        var nodes = xpathEval( '/initializeResponse/instance', ctx );
                        
                        YAHOO.log( nodes.toString() );
                        
                        if( null != nodes ) {
                            var nodeSet = nodes.nodeSetValue();
                            YAHOO.log( 'Generating module ' +  nodeSet.length + ' instances' );
                            for( var i = 0; i < nodeSet.length; ++i ) {
                                var m = new QSEGenericModule();
                                m.init( nodeSet[ i ] );
                                qse.registerModuleInstance( m );
                            }
                        }
                        else {
                            alert( 'No moduleContainers found during initialization' );
                        }
                        delete ctx;
                        YAHOO.log( 'Registration done event firing' );
                        qse.registrationDoneEvent.fire( m.getClassName() );
                    },
                    failure : function( resp ) {
                        alert( 'QSEGenericModule: Initialization failed: ' +
                               'Status: ' + resp.status + '\n' +
                               'Status message: ' + resp.statusText );
                    },
                    timeout : qse.getTransactionTimeout()
                }
        
                var postBody = '';
                var url = "/QSEGenericModule/initialize";
                YAHOO.util.Connect.initHeader( 'ContentType', 'text/xml' );
                YAHOO.util.Connect.asyncRequest( 'POST', url,
                                                 callback, postBody );
            }
            catch( e ) {
                alert( 'Caught exception: ' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
            }
        }
    )
})();

/**
 *  The saveHandler_g, resetHandler_g and testHandler_g functions are in the
 *  global scope because they are registered as event handlers on the dialog
 *  buttons.  As a result, the functions will always be called in the scope of 
 *  the dialog ( 'this' will be the dialog object ).  The QSEParentModule
 *  property of the dialog will be the module object and can be used to get
 *  into the proper scope.
 */
saveHandler_g = function( event ) {
    this.QSEParentModule.saveHandler( this.getData() );
}

resetHandler_g = function( event ) {
    this.QSEParentModule.resetHandler( this.getData() );
}

testHandler_g = function( event ) {
    this.QSEParentModule.testHandler( this.getData() );
}

/*******************************************************************************
 *
 *  'Class'
 */
function QSEGenericModule( instanceNode ) {
    /**
     *  data used by the UI framework
     */
    this.className      = 'QSEGenericModule';
    this.name       = '';
    this.label      = '';
    this.group      = '';
    this.buttons    = [
        { text: "Ok",    handler: saveHandler_g, isdefault: true },
        { text: "Reset", handler: resetHandler_g }
    ];

    this.validateStatus = function() {
        for( var i = 0; i < this.data.length; ++i ) {
            var dp = this.data[ i ];
            if( 'int' == dp.type ) {
                var v = parseInt( dp.value );
                if( isNaN( v ) ||
                    parseInt( dp.max ) < v ||
                    v < parseInt( dp.min ) ) {
                    return false;
                }
            }
            else if( 'float' == dp.type ) {
                var v = parseFloat( dp.value ); 
                if( isNaN( v ) ||
                    parseFloat( dp.max ) < v || 
                    v < parseFloat( dp.min ) ) {
                    return false;
                }
            }
            else if( 'enum' == dp.type ) {
                var ok = false;
                for( var j = 0; j < dp.values.length; ++j ) {
                    if( dp.value == dp.values[ j ] ) {
                        ok = true;
                        break;
                    }
                }
                if( !ok ) {
                    return false;
                }
            }
        }
        return true;
    }

    this.getStatus = function() {
        return( this.validateStatus() ? "Ok" : "Fail" );
    }

    this.passwordCfmStr = '___cfm';

    this.getEnumValues = function( tagNode ) {
        var a = new Array();
        var ctx = new ExprContext( tagNode );
        var nodes = xpathEval( 'enumValue', ctx );
        if( null != nodes ) {
            var set = nodes.nodeSetValue();
            for( var i = 0; i < set.length; ++i ) {
                a.push( xmlValue( set[ i ] ) );
            }
        }
        return a;
    }

    this.data = new Array();

    this.init = function( instanceNode ) {
        try {
            var ctx = new ExprContext( instanceNode );
            this.name    = xpathEval( 'name',    ctx ).stringValue();
            this.label   = xpathEval( 'label',   ctx ).stringValue();
            this.group   = xpathEval( 'group',   ctx ).stringValue();
            this.groupDisp = xpathEval( 'groupDisplay',   ctx ).stringValue();
            this.display = xpathEval( 'display', ctx ).stringValue();
            this.markup  = xpathEval( 'markup',  ctx ).stringValue();

            YAHOO.log( 'Generic init \n' + 
                       '    name    = ' + this.name    + '\n' +
                       '    label   = ' + this.label   + '\n' +
                       '    group   = ' + this.group   + '\n' +
                       '    display = ' + this.display + '\n' +
                       '    markup  = ' + this.markup  + '\n' );

            var nodes = xpathEval( 'tag', ctx );
            if( null != nodes ) {
                var nodeSet = nodes.nodeSetValue();
                for( var i = 0; i < nodeSet.length; ++i ) {
                    var ctx2 = new ExprContext( nodeSet[ i ] );
                    var n  = getAttrValue( 'name',  ctx2 );
                    var l  = getAttrValue( 'label', ctx2 );
                    var v  = getAttrValue( 'value', ctx2 );
                    var t  = getAttrValue( 'type',  ctx2 );
                    var mn = getAttrValue( 'min',   ctx2 );
                    var mx = getAttrValue( 'max',   ctx2 );
                    var vs = this.getEnumValues( nodeSet[ i ] );
                    this.data.push( new DataPoint( n, l, v, t, mn, mx, vs ) );
                    if( 'password' == t ) {
                        this.data.push( new DataPoint( n + this.passwordCfmStr,
                                                       l + '(confirm)', 
                                                       v, t, mn, mx, vs ) );
                    }
                    delete ctx2;
                }
            }
            delete ctx;
        }
        catch( e ) {
            alert( 'Caught exception:\n' + e.message + '\n' + e.fileName + ':' + e.lineNumber );
        }
    }

    /**********************************************************************
     *
     *  Functions that implement the required module interface
     */
    this.getData = function() {
        YAHOO.log( 'Getting generic data ' + this.name + ' ' + this.data.length );
        var data = new Array();
        for( var i = 0; i < this.data.length; ++i ) {
            var dp = this.data[ i ];
            if( 'password' != dp.type ||
                -1 == dp.name.lastIndexOf( this.passwordCfmStr ) ) {
                data.push( new NVP( dp.name, dp.value, dp.purpose ) );
            }
        }
        return data;
    }
    
    this.show = function() {
        YAHOO.log( 'showing module ' + this.name );
        for( var i = 0; i < this.data.length; ++i ) {
            var dp = this.data[ i ];
            YAHOO.log( dp.name + '   ' + dp.value );
            document.getElementById( dp.name ).value = dp.value;
        }
    }

    this.hide = function() {
    }
    
    this.confirmPasswords = function( dlgData ) {
        for( var i = 0; i < this.data.length; ++i ) {
            var dp = this.data[ i ];
            if( 'password' == dp.type && 
                -1 == dp.name.lastIndexOf( this.passwordCfmStr ) ) {
                if( dlgData[ dp.name ] != 
                    dlgData[ dp.name + this.passwordCfmStr ] ) {
                    alert( 'Passwords do not match for ' + dp.label );
                    return false;
                }
            }
        }

        return true;
    }
    
    this.validateDlgData = function( dlgData ) {
        if( !this.confirmPasswords( dlgData ) ) {
            return false;
        }

        for( var i = 0; i < this.data.length; ++i ) {
            var dp = this.data[ i ];
            if( 'int' == dp.type ) {
                var v = parseInt( dlgData[ dp.name ] );
                if( v != dlgData[ dp.name ] ) {
                    alert( 'Invalid data: ' + dp.label + ' contains invalid digits' );
                    return false;
                }
                if( v == NaN ||
                    parseInt( dp.max ) < v || v < parseInt( dp.min ) ) {
                    alert( 'Invalid data: ' + dp.label + ' is out of range [' + 
                           dp.min + ', ' + dp.max + ']' );
                    return false;
                }
            }
            else if( 'float' == dp.type ) {
                var v = parseFloat( dlgData[ dp.name ] );
                if( v != dlgData[ dp.name ] ) {
                    alert( 'Invalid data: ' + dp.label + ' contains invalid digits' );
                    return false;
                }
                if( v == NaN || 
                    parseFloat( dp.max ) < v || v < parseFloat( dp.min ) ) {
                    alert( 'Invalid data: ' + dp.label + ' is out of range [' + 
                           dp.min + ', ' + dp.max + ']' );
                    return false;
                }
            }
        }
        return true;
    }

    this.dataIsDirty = function( dlgData ) {
        var dirty = false;
        for( var i = 0; i < this.data.length; ++i ) {
            var dp = this.data[ i ];
            if( dp.value.toString() != dlgData[ dp.name ].toString() ) {
                dirty = true;
            }
        }
        return dirty;
    }

    this.saveHandler = function( dlgData ) {
        if( this.validateDlgData( dlgData ) && 
            this.dataIsDirty( dlgData ) ) {
            for( var i = 0; i < this.data.length; ++i ) {
                var dp = this.data[ i ];
                YAHOO.log( dp.name + '   ' + dp.value );
                dp.value = document.getElementById( dp.name ).value;
            }
            qse.statusDataChangedEvent.fire( this );
        }
    }

    this.resetHandler = function( dlgData ) {
        this.show();
    }

    this.createRow = function( doc, dp ) {
        //  create nodes
        var row = doc.createElement( 'tr' );
        var td1 = doc.createElement( 'td' );
        var td2 = doc.createElement( 'td' );
        var lbl = doc.createElement( 'label' );
        var txt = doc.createTextNode( dp.label );
        var inp = null;
        var type = null;

        if( 'enum' == dp.type ) {
            inp = doc.createElement( 'select' );
            for( var j = 0; j < dp.values.length; ++j ) {
                var opt = doc.createElement( 'option' );
                opt.appendChild( doc.createTextNode( dp.values[ j ] ) );
                opt.setAttribute( 'value', dp.values[ j ] );
                inp.appendChild( opt );
            }
            type = '';
        }
        else if( 'password' == dp.type ) {
            inp = doc.createElement( 'input' );
            type = 'password';
        }
        else {
            inp = doc.createElement( 'input' );
            type = 'text';
        }

        //  add attributes
        lbl.setAttribute( 'for', dp.name );
        inp.setAttribute( 'id', dp.name );
        inp.setAttribute( 'type', type );
        inp.setAttribute( 'name', dp.name );

        //  assemble
        lbl.appendChild( txt );
        td1.appendChild( lbl );
        td2.appendChild( inp );
        row.appendChild( td1 );
        row.appendChild( td2 );
        
        return row;
    }

    this.buildMarkup = function() {
        var doc = new XDocument();
        var form = doc.createElement( 'form' );
        var table = doc.createElement( 'table' );
        for( var i = 0; i < this.data.length; ++i ) {
            var dp = this.data[ i ];

            var row = this.createRow( doc, dp, false );
            table.appendChild( row );
        }
        form.appendChild( table );
        doc.appendChild( form );

        return xmlText( doc );
    }

    this.getMarkup = function() {
    
        YAHOO.log( this.name + ' getMarkup\n\n\n\n\n' );
    
        if( 0 < this.markup.length ) {
            YAHOO.log( 'returning - ' + this.markup );
            return this.markup;
        }
        else {
            YAHOO.log( 'returning - ' + this.buildMarkup() );
            return this.buildMarkup();
        }
    }

    YAHOO.log( this.className + '\n' +
               this.name  + '\n' +
    this.label  + '\n' +
    this.group  + '\n' );
}

/*******************************************************************************
 *
 *  Inherit everything else from the base module
 */
QSEGenericModule.prototype = QSEBaseModule.prototype;
