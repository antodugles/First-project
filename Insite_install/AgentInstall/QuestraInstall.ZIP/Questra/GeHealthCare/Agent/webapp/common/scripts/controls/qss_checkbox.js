/**
 * Quetra javascript functions for column checkbox in the table header.
 */

function doChecks(f, theElement, tag)
{
   var selectAll = "select_all_" + tag;
   if (theElement.name==selectAll)
   {
      var bChecked = theElement.checked;
      for(var i=0; i<f.elements.length; i++)
         if (f.elements[i].type=='checkbox')
            if(f.elements[i].name==tag)
               f.elements[i].checked=bChecked;
   }
}

function checkSelectAll(f, theElement)
{
   var tag = theElement.name;
   if( !theElement.checked )
   {
      eval( "f.select_all_" + tag + ".checked = false;" );
   }
}
